## License

This resourcepack is under the [Attribution-NonCommercial-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-nc-sa/4.0/) license.

This basically just means you can use the assets in this pack however you want to as long as it's not for-profit, and you properly credit me.

For crediting, you can use this link: https://gist.github.com/Xetheon/c3d677e0762658f8d79cf05e2c6e65ff
